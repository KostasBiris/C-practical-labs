#include "lib_interface.h"

int main(){
  run_lib_interface();
  return 0;
}
