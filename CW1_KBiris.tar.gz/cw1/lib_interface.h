#ifndef LIB_INTERFACE_GUARD_H
#define LIB_INTERFACE_GUARD_H

#include "book_management.h"
#include "users.h"
#include "library.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void run_lib_interface();
#endif
